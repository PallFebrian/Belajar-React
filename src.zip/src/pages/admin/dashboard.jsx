export default function Dashboard() {
  return (
    <div>
      <h1>Dashboard Page</h1>
    </div>
  );
}
