export default function Kelas() {
  return (
    <div>
      <h1>Kelas Page</h1>
    </div>
  );
}
