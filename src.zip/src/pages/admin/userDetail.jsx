export default function UserDetail() {
  return (
    <div>
      <h1>User Detail </h1>
      <div className="mt-5">Nama :ihsan</div>
      <div>Kelas :xi rpl</div>
    </div>
  );
}
